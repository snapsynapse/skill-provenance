# Capability Scanner: Operations Guide

Status: v1.0
Last updated: 2026-03-07

This document describes how the capability-scanner skill and its recurring automated task work together, how to troubleshoot common problems, and how to maintain the system over time.

---

## System Overview

The AI Capability Reference Scanner is a two-part system:

1. **The Skill** (`capability-scanner/SKILL.md`) — An editorial decision framework that encodes the project's scope rules, ontology, inclusion criteria, and assessment format. It is a reusable set of instructions that any agent can load and follow.

2. **The Recurring Task** — A scheduled background agent that runs every 3 days. It loads the skill, scans the AI ecosystem for changes, applies the editorial framework, and creates GitHub issues for candidates that pass the filter.

Neither part works alone. The skill provides judgment without action. The task provides action without judgment. Together they form a closed loop: scan → assess → file → log → notify.

### How They Relate

```
┌──────────────────────────────────────────────────┐
│              Recurring Task (every 3 days)        │
│                                                   │
│  1. Load capability-scanner skill                 │
│  2. Search web for AI announcements               │
│  3. Apply skill's filter criteria                 │
│  4. Produce structured assessments                │
│  5. Create GitHub issues via PAT                  │
│  6. Append to scan log                            │
│  7. Send notification (if findings exist)         │
│                                                   │
│  Inputs:     SKILL.md (editorial rules)           │
│              github-token.txt (API access)        │
│              scan-log.md (history)                 │
│                                                   │
│  Outputs:    GitHub issues on the repo            │
│              scan-log.md entries                   │
│              In-app notifications                  │
└──────────────────────────────────────────────────┘
```

### What Lives Where

| Item | Location | Purpose |
|------|----------|---------|
| Skill definition | `capability-scanner/SKILL.md` | Editorial framework, ontology, assessment format |
| This operations guide | `capability-scanner/OPERATIONS.md` | Human and agent troubleshooting |
| GitHub PAT | `cron_tracking/capability-scanner/github-token.txt` | Authentication for issue creation |
| Scan log | `cron_tracking/capability-scanner/scan-log.md` | Append-only history of every scan |
| Fallback findings | `cron_tracking/capability-scanner/findings.md` | Created only when GitHub is unavailable |

---

## The Skill

### What It Contains

The skill encodes everything an agent needs to make editorial decisions about the AI Capability Reference:

- **Project context**: What the repo is, who it serves, what platforms are tracked
- **Inclusion criteria**: Rules for when a provider, product, implementation, capability, or plan should be added
- **Ontology**: The six entity types (Capability, Implementation, Model, Provider, Plan, Model-Access) and how to classify candidates
- **Capability taxonomy**: The seven groups (Understand, Respond, Create, Work With My Stuff, Act For Me, Connect, Access Context) with specific capability slugs
- **Scanning instructions**: Step-by-step process for gathering signals, filtering, assessing, and filing issues
- **Quality rules**: Five editorial guardrails (require official sources, prefer accuracy over completeness, apply the core rule, watch for ontology drift, respect useful truth)
- **Data schema reference**: The markdown format used in `data/platforms/` files

### When It Is Used

The skill is loaded in two contexts:

1. **Automatically by the recurring task** — Every 3 days the background agent loads it before scanning.
2. **Manually by a human** — You can ask Perplexity Computer to "load the capability-scanner skill and assess [some announcement or topic]" at any time. This is useful for ad-hoc evaluation of something you spotted yourself.

### How to Update the Skill

If the project's scope, ontology, tracked platforms, or editorial criteria change, the skill should be updated to match. The canonical sources of truth are the repo's governance documents:

- `SCOPE.md` — Inclusion/exclusion rules
- `ONTOLOGY.md` — Entity types and relationships
- `CAPABILITY_TAXONOMY.md` — Capability groups and slugs
- `data/_schema.md` — Data format for platform files
- `PROJECT_GOALS.md` — Audience, philosophy, and information model

To update the skill, ask Perplexity Computer to update the `capability-scanner` skill with the new criteria. It will re-validate and re-save to the skill library.

---

## The Recurring Task

### Schedule

- **Frequency**: Every 3 days
- **Time**: 8:00 AM MST (15:00 UTC)
- **Task ID**: `d06402a4`
- **Type**: Background (runs in an isolated agent without conversation history)

### What It Does Each Run

1. **Loads the skill** — Reads `capability-scanner/SKILL.md` for editorial rules
2. **Gathers signals** — Searches official blogs, tech press, and pricing pages for AI product changes in the last 7 days
3. **Filters for relevance** — Applies the skill's pass/skip criteria to each signal
4. **Assesses candidates** — Produces a structured assessment for each passing signal (entity type, capability mapping, scope assessment, recommendation, evidence, urgency)
5. **Deduplicates** — Searches existing open issues on the repo before creating new ones
6. **Creates GitHub issues** — Uses `curl` with the fine-grained PAT to file issues on `snapsynapse/ai-capability-reference`
7. **Logs the scan** — Appends a summary to `scan-log.md`
8. **Notifies** — Sends an in-app notification if ADD or UPDATE candidates were found; stays silent if nothing new was found

### GitHub Authentication

The task uses a fine-grained GitHub Personal Access Token (PAT) stored at:

```
cron_tracking/capability-scanner/github-token.txt
```

This token is scoped to:
- **Repository**: `snapsynapse/ai-capability-reference` only
- **Permission**: Issues (read and write) only
- **No access** to private repos, code, pull requests, or any other repo

The task reads the token at runtime and uses it with `curl` against the GitHub REST API. It does not use Perplexity's GitHub OAuth connector.

### Issue Format

Issues created by the scanner follow this pattern:

**Title**: `[Scanner] Add: Feature Name` or `[Scanner] Update: Feature Name — What changed` or `[Scanner] Watch: Feature Name`

**Body**: Full structured assessment in markdown, including entity type, capability mapping, relevance, scope assessment, recommendation, evidence URLs, and urgency level.

**Labels**: `scanner` (if the label exists on the repo)

---

## Troubleshooting Guide

### For Humans

#### The scanner hasn't created any issues recently

**Check the scan log first.** Read `cron_tracking/capability-scanner/scan-log.md` to see if scans are running. If recent entries exist but show "0 candidates found," the ecosystem was quiet — this is normal.

If the log has no recent entries, the recurring task may have stopped. Ask Perplexity Computer: "List my scheduled tasks" — it should show the AI Capability Reference Scanner. If it's missing, re-create it.

#### Issues are being created but they seem wrong

The skill's editorial criteria may need updating. Check whether the repo's `SCOPE.md`, `ONTOLOGY.md`, or `CAPABILITY_TAXONOMY.md` have changed since the skill was last updated. If so, ask Perplexity Computer to "update the capability-scanner skill to match the current repo governance docs."

#### The scanner created a duplicate issue

The task searches open issues before creating new ones, but the search is keyword-based and may miss near-duplicates. Close the duplicate on GitHub and note the pattern — if it keeps happening for a specific feature, the issue title format may need adjustment.

#### I want to change the scan frequency

Ask Perplexity Computer: "Change the AI Capability Reference Scanner to run [daily / weekly / every N days]." It will update the scheduled task.

#### I want to run a scan right now

Ask Perplexity Computer: "Load the capability-scanner skill and run a scan now." It will execute the full scanning process in-conversation rather than waiting for the next scheduled run.

#### I want to evaluate a specific announcement

Ask Perplexity Computer: "Load the capability-scanner skill and assess [paste the announcement or describe it]." It will apply the editorial framework to that specific item and give you a recommendation.

#### The GitHub token expired

The fine-grained PAT has an expiration date you set when creating it. When it expires:

1. The scanner will fail to create issues and will save findings to `cron_tracking/capability-scanner/findings.md` instead
2. It will send a notification telling you the token needs to be refreshed
3. Create a new token at [github.com/settings/tokens?type=beta](https://github.com/settings/tokens?type=beta) with the same settings (repo: `snapsynapse/ai-capability-reference`, permission: Issues read/write)
4. Tell Perplexity Computer: "Update the capability-scanner GitHub token to [new token]"

#### I want to add or remove a tracked platform

1. Update the repo's `SCOPE.md` to reflect the change
2. Ask Perplexity Computer: "Update the capability-scanner skill — [platform] has been added/removed from the tracked platforms"
3. The next scan will use the updated criteria

#### I want to stop the scanner entirely

Ask Perplexity Computer: "Delete the AI Capability Reference Scanner scheduled task." This permanently removes the recurring task. The skill remains in your library for manual use.

### For Agents

This section is written for AI agents that load this skill or execute the recurring task.

#### Before scanning

1. Load the `capability-scanner` skill. All editorial rules are in SKILL.md.
2. Read the scan log at `cron_tracking/capability-scanner/scan-log.md` to determine when the last scan ran and what was found. This prevents re-filing issues for the same announcements.
3. Verify the GitHub token exists at `cron_tracking/capability-scanner/github-token.txt`. If the file is missing, skip issue creation and save findings to `cron_tracking/capability-scanner/findings.md` instead.

#### During scanning

1. Search broadly first, then filter. It is better to find 20 signals and filter down to 3 than to miss something by searching too narrowly.
2. For each candidate, determine the entity type BEFORE assessing scope. "What kind of thing is this?" comes before "Does it belong?"
3. Always check for existing open issues before creating new ones. Use the GitHub search API: `GET /search/issues?q=repo:snapsynapse/ai-capability-reference+is:issue+is:open+KEYWORD`
4. If the GitHub API returns 401 (unauthorized) or 403 (forbidden), the token has expired or been revoked. Do not retry. Save findings to the fallback file and notify the user.
5. If the GitHub API returns 422 (validation error), the issue body may contain invalid characters or the label may not exist. Try creating the issue without labels. If that fails, save to the fallback file.

#### After scanning

1. Always append to the scan log, even if nothing was found. An empty scan is still a data point.
2. Only send a notification if ADD or UPDATE candidates were found. WATCH-only scans and empty scans should end silently.
3. Do not modify the skill file. If the skill's criteria seem outdated, note it in the scan log and notify the user.

#### Common failure modes

| Symptom | Likely Cause | Action |
|---------|-------------|--------|
| Token file missing | File was deleted or path changed | Save findings to fallback, notify user |
| GitHub API 401 | Token expired or revoked | Save findings to fallback, notify user to refresh token |
| GitHub API 403 | Token lacks permission | Save findings to fallback, notify user |
| GitHub API 422 | Invalid issue body or label | Retry without labels; if still failing, save to fallback |
| GitHub API 404 | Repo name wrong or repo deleted | Save findings to fallback, notify user |
| No search results | Quiet period or search queries too narrow | Log the scan as empty, do not notify |
| Too many candidates (10+) | Major product event (e.g., Google I/O) | Process all, but note the unusual volume in the scan log |
| Skill not found | Skill was removed from library | Notify user that the capability-scanner skill needs to be re-saved |

---

## Maintenance Checklist

### Monthly

- [ ] Check `scan-log.md` for consistent scan entries (should see ~10 per month)
- [ ] Review open `[Scanner]` issues on GitHub — close any that have been addressed or are no longer relevant
- [ ] Verify the GitHub PAT expiration date — rotate before it expires

### When the Repo Changes

- [ ] If `SCOPE.md` changes: update the skill's inclusion criteria and tracked platforms
- [ ] If `ONTOLOGY.md` changes: update the skill's entity types section
- [ ] If `CAPABILITY_TAXONOMY.md` changes: update the skill's capability taxonomy section
- [ ] If `data/_schema.md` changes: update the skill's data schema reference
- [ ] If a new platform is added to the repo: add it to the skill's tracked platforms list

### When Perplexity Computer Changes

The recurring task depends on:
- `search_web` — for gathering signals
- `fetch_url` — for reading official pages
- `bash` with `curl` — for GitHub API calls
- `send_notification` — for alerting the user

If any of these tools change behavior, the task instructions may need adjustment. The skill itself is tool-agnostic and should not need changes.

---

## Architecture Decision Records

### Why a skill + recurring task instead of just a recurring task?

The editorial judgment is complex (ontology, scope rules, capability taxonomy, six entity types, five quality rules). Embedding all of that in a cron task description would make it fragile and hard to update. Separating the "what to decide" (skill) from the "when to run" (task) means:

- The skill can be updated independently of the schedule
- The skill can be invoked manually for ad-hoc assessments
- The task instructions stay short and focused on execution
- Other agents or workflows can reuse the same editorial framework

### Why curl + PAT instead of the GitHub connector?

The GitHub OAuth connector requests access to all repositories including private ones. A fine-grained PAT scoped to a single public repo with only Issues permission provides the minimum necessary access. The tradeoff is manual token rotation, but this is a reasonable cost for the security benefit.

### Why every 3 days instead of daily?

The AI ecosystem moves fast but not so fast that daily scanning adds value over every-3-days scanning. Most significant feature launches are announced with lead time, and pricing changes rarely happen without notice. Every 3 days balances coverage against resource usage. This can be changed at any time.

### Why background mode?

The scanner does not need conversation history or user interaction during execution. Background mode keeps it isolated, prevents it from cluttering the conversation, and allows it to run even when the user is not active.
